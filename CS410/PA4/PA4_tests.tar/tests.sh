#!/bin/bash
./Release/PA4 tests/spheres_camera.txt tests/sphere_materials_1.txt tests/sphere_0.ply tests/scaled_plane.ply output_1.ppm
./Release/PA4 tests/spheres_camera.txt tests/sphere_materials_2.txt tests/sphere_0.ply tests/scaled_plane.ply output_2.ppm
./Release/PA4 tests/spheres_camera.txt tests/spheres_materials_3.txt tests/sphere_0.ply tests/sphere_1.ply tests/sphere_2.ply tests/sphere_3.ply tests/sphere_4.ply tests/sphere_5.ply tests/sphere_6.ply tests/sphere_7.ply tests/sphere_8.ply tests/scaled_plane.ply output_3.ppm
./Release/PA4 tests/spheres_camera_side_view.txt tests/spheres_materials_4.txt tests/sphere_0.ply tests/sphere_1.ply tests/sphere_2.ply tests/sphere_3.ply tests/sphere_4.ply tests/sphere_5.ply tests/sphere_6.ply tests/sphere_7.ply tests/sphere_8.ply tests/scaled_plane.ply output_4.ppm

